console.log("mi primer js")
console.log("sigamos aprendiendo")

var a = 3
var b = 4
var c = 2

console.log("suma: "+ (a+b+c))
