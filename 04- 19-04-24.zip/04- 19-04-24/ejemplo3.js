function suma(a,b){
    if(a === b){
        return (a+b)*3
    }
    else{
        return (a+b)
    }
}

console.log(suma(2,"2"))