document.getElementById("primero").style.color="red"
document.getElementById("segundo").style.border="solid"
document.getElementById("tercero").style.color="blue"
console.log("Un show!!!")