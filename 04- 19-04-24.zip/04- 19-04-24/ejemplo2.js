let today = new Date()
console.log(today)

let dd = today.getDate()
let mm = today.getMonth() + 1
let yyyy = today.getFullYear()

console.log(dd+"/"+mm+"/"+yyyy)
console.log(`${dd}/${mm}/${yyyy}`)
