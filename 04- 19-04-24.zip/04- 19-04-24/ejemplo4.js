function sumar(a,b){
    return a+b
}

sumar2 = function(a,b){
    return a+b
}

sumar3 = (a,b) => {
    return a+b
}

console.log(sumar(2,2))
console.log(sumar2(2,2))
console.log(sumar3(2,2))